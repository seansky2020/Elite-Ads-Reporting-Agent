import { GoogleGenAI, Type, Chat } from "@google/genai";
import { ReportData, ReportGenerationResult } from '../types';

export const generateReport = async (csvData: string): Promise<ReportGenerationResult> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

    const prompt = `
      You are an Elite AI-powered Facebook Ads Reporting Agent. Your audience is executive-level decision-makers.
      Analyze the following Meta Ads performance data from a CSV file. Provide deep, actionable insights and strategic recommendations.
      Your tone must be clear, professional, and insight-driven. Focus on what matters most for business growth and ROI. Do not just state the data; interpret it.

      The CSV data might use different column names for metrics. You need to intelligently identify them. Common names include:
      - Spend: 'Amount Spent (USD)', 'Spend', 'Cost'
      - Revenue/Conversions Value: 'Website Conversion Value', 'Purchase ROAS [return on ad spend]', 'Total Conversion Value', 'Revenue'
      - CPA: 'Cost per Result', 'CPA', 'Cost Per Action'
      - ROAS: 'Purchase ROAS [return on ad spend]', 'ROAS'
      - Clicks: 'Clicks (All)', 'Link Clicks'
      - Impressions: 'Impressions'
      - CTR: 'CTR (All)', 'Click-Through Rate'
      - CPC: 'CPC (All)', 'Cost Per Click'
      - Campaign Name: 'Campaign Name'

      Calculate the overall Key Metrics by summing up the relevant columns. Format currency values with a dollar sign and commas (e.g., "$1,234.56"). Format ROAS as a number with two decimal places (e.g., "2.54"). Format CTR as a percentage with two decimal places (e.g., "1.23%").

      CSV Data:
      \`\`\`csv
      ${csvData}
      \`\`\`

      Based on this data, generate a report in the specified JSON format.
      For the chart data, select the top 5-7 campaigns by spend and provide their calculated ROAS and CPA.
      If there are fewer than 5 campaigns, include all of them.
      Ensure your insights are high-level and strategic, and your recommendations are specific and actionable.
    `;

    const reportSchema = {
        type: Type.OBJECT,
        properties: {
          keyMetrics: {
            type: Type.OBJECT,
            properties: {
              totalSpend: { type: Type.STRING, description: "Total ad spend, formatted as currency." },
              totalRevenue: { type: Type.STRING, description: "Total revenue generated, formatted as currency." },
              roas: { type: Type.STRING, description: "Overall Return On Ad Spend, formatted as a number string." },
              impressions: { type: Type.STRING, description: "Total impressions, formatted as a number string with commas." },
              clicks: { type: Type.STRING, description: "Total clicks, formatted as a number string with commas." },
              ctr: { type: Type.STRING, description: "Overall Click-Through Rate, formatted as a percentage string." },
              cpc: { type: Type.STRING, description: "Overall Cost Per Click, formatted as currency." },
              cpa: { type: Type.STRING, description: "Overall Cost Per Acquisition/Action, formatted as currency." },
            },
            required: ["totalSpend", "totalRevenue", "roas", "impressions", "clicks", "ctr", "cpc", "cpa"],
          },
          insights: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 3-4 high-level, actionable insights from the data."
          },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 3-4 specific, strategic recommendations."
          },
          chartData: {
            type: Type.ARRAY,
            description: "Data for the top 5-7 campaigns by spend.",
            items: {
              type: Type.OBJECT,
              properties: {
                campaignName: { type: Type.STRING },
                roas: { type: Type.NUMBER },
                cpa: { type: Type.NUMBER },
              },
              required: ["campaignName", "roas", "cpa"],
            },
          },
        },
        required: ["keyMetrics", "insights", "recommendations", "chartData"],
      };


    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: reportSchema,
            temperature: 0.2,
        }
    });
    
    const jsonText = response.text.trim();
    const report = JSON.parse(jsonText) as ReportData;

    const chat = ai.chats.create({
        model: 'gemini-2.5-pro',
        systemInstruction: `You are the Elite AI Ads Reporting Agent who just generated the following report for an executive.
        Your persona is professional, insightful, and helpful.
        You must answer questions based *only* on the provided CSV data and the report summary. Do not hallucinate or use external knowledge.
        If a question cannot be answered from the data, state that clearly.

        ---
        ORIGINAL CSV DATA:
        \`\`\`csv
        ${csvData}
        \`\`\`
        ---
        GENERATED REPORT SUMMARY:
        ${JSON.stringify(report, null, 2)}
        ---

        Now, answer the user's follow-up questions. Keep your answers concise and to the point.
        `,
    });

    return { report, chat };
};