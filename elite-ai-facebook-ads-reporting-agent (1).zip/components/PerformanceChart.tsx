
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Label } from 'recharts';
import { ChartDataPoint } from '../types';

interface PerformanceChartProps {
  data: ChartDataPoint[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-md shadow-lg border border-slate-200">
          <p className="font-bold text-slate-800">{`${label}`}</p>
          <p className="text-sm text-indigo-600">{`ROAS: ${payload[0].value}`}</p>
          <p className="text-sm text-teal-600">{`CPA: $${payload[1].value.toFixed(2)}`}</p>
        </div>
      );
    }
  
    return null;
  };

const PerformanceChart: React.FC<PerformanceChartProps> = ({ data }) => {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{
          top: 5,
          right: 20,
          left: 20,
          bottom: 20,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
        <XAxis 
            dataKey="campaignName" 
            tick={{ fontSize: 12, fill: '#64748b' }} 
            angle={-10} 
            textAnchor="end"
            height={50}
            interval={0}
        />
        <YAxis yAxisId="left" orientation="left" stroke="#818cf8" tick={{ fontSize: 12, fill: '#64748b' }}>
            <Label value="ROAS" angle={-90} position="insideLeft" style={{ textAnchor: 'middle', fill: '#4f46e5' }} />
        </YAxis>
        <YAxis yAxisId="right" orientation="right" stroke="#14b8a6" tickFormatter={(value) => `$${value}`} tick={{ fontSize: 12, fill: '#64748b' }}>
            <Label value="CPA ($)" angle={90} position="insideRight" style={{ textAnchor: 'middle', fill: '#0d9488' }} />
        </YAxis>
        <Tooltip content={<CustomTooltip />} cursor={{fill: 'rgba(238, 242, 255, 0.6)'}}/>
        <Legend wrapperStyle={{paddingTop: '20px'}}/>
        <Bar yAxisId="left" dataKey="roas" fill="#818cf8" name="ROAS" radius={[4, 4, 0, 0]} />
        <Bar yAxisId="right" dataKey="cpa" fill="#2dd4bf" name="CPA" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default PerformanceChart;
