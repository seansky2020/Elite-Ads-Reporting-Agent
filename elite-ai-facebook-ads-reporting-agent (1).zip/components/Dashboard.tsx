
import React from 'react';
import { ReportData, ChatMessage } from '../types';
import MetricCard from './MetricCard';
import PerformanceChart from './PerformanceChart';
import Chat from './Chat';
import { LightbulbIcon, TargetIcon, CsvIcon } from './Icons';

interface DashboardProps {
  report: ReportData;
  fileName: string;
  chatHistory: ChatMessage[];
  isChatLoading: boolean;
  onSendMessage: (message: string) => Promise<void>;
}

const Dashboard: React.FC<DashboardProps> = ({ report, fileName, chatHistory, isChatLoading, onSendMessage }) => {
  const { keyMetrics, insights, recommendations, chartData } = report;

  return (
    <div className="space-y-8 animate-fade-in">
        <div className="p-4 bg-white rounded-lg shadow-sm border border-slate-200 flex items-center">
            <CsvIcon className="h-6 w-6 text-indigo-600 mr-3"/>
            <p className="text-sm text-slate-700">
                Displaying analysis for: <span className="font-semibold">{fileName}</span>
            </p>
        </div>

      {/* Key Metrics */}
      <section>
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Executive Summary</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <MetricCard title="Total Spend" value={keyMetrics.totalSpend} />
          <MetricCard title="Total Revenue" value={keyMetrics.totalRevenue} />
          <MetricCard title="ROAS" value={keyMetrics.roas} />
          <MetricCard title="CPA" value={keyMetrics.cpa} />
          <MetricCard title="Impressions" value={keyMetrics.impressions} />
          <MetricCard title="Clicks" value={keyMetrics.clicks} />
          <MetricCard title="CTR" value={keyMetrics.ctr} />
          <MetricCard title="CPC" value={keyMetrics.cpc} />
        </div>
      </section>

      {/* Insights and Recommendations */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200">
          <h3 className="flex items-center text-xl font-bold text-slate-800 mb-4">
            <LightbulbIcon className="h-6 w-6 mr-2 text-yellow-500" />
            Actionable Insights
          </h3>
          <ul className="space-y-3 text-slate-600">
            {insights.map((insight, index) => (
              <li key={index} className="flex items-start">
                <span className="text-indigo-500 font-bold mr-2 mt-1">&#8227;</span>
                <span>{insight}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200">
          <h3 className="flex items-center text-xl font-bold text-slate-800 mb-4">
            <TargetIcon className="h-6 w-6 mr-2 text-green-500" />
            Strategic Recommendations
          </h3>
          <ul className="space-y-3 text-slate-600">
            {recommendations.map((rec, index) => (
              <li key={index} className="flex items-start">
                <span className="text-indigo-500 font-bold mr-2 mt-1">&#8227;</span>
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Performance Chart */}
      <section className="bg-white p-6 rounded-xl shadow-lg border border-slate-200">
        <h3 className="text-xl font-bold text-slate-800 mb-1">Top Campaign Performance</h3>
        <p className="text-sm text-slate-500 mb-6">Comparison of ROAS and CPA for top-spending campaigns.</p>
        <div className="w-full h-96">
            <PerformanceChart data={chartData} />
        </div>
      </section>

      {/* Chat Section */}
      <section>
        <Chat 
            history={chatHistory} 
            isLoading={isChatLoading} 
            onSendMessage={onSendMessage} 
        />
      </section>
    </div>
  );
};

export default Dashboard;
