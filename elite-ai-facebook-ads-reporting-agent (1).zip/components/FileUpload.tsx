
import React, { useCallback, useRef, useState } from 'react';
import { UploadIcon, CsvIcon } from './Icons';

interface FileUploadProps {
  onFileUpload: (content: string, fileName: string) => void;
  isLoading: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload, isLoading }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((file: File | null) => {
    if (file && file.type === 'text/csv') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        if (content) {
          onFileUpload(content, file.name);
        }
      };
      reader.readAsText(file);
    } else {
      alert('Please upload a valid .csv file.');
    }
  }, [onFileUpload]);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
      e.dataTransfer.clearData();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFile(e.target.files[0]);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };
  
  if (isLoading) {
    return (
       <div className="text-center p-12 bg-white rounded-xl shadow-lg border border-slate-200">
         <div className="flex justify-center items-center mb-4">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
         </div>
         <h3 className="text-lg font-semibold text-slate-800">Analyzing Your Data...</h3>
         <p className="text-slate-500 mt-2">Our AI agent is crafting your executive report. This may take a moment.</p>
       </div>
    );
  }

  return (
    <div className="text-center bg-white p-8 rounded-xl shadow-lg border border-slate-200">
        <div 
            className={`relative flex flex-col items-center justify-center w-full p-10 border-2 border-dashed rounded-lg transition-colors duration-200 ${isDragging ? 'border-indigo-600 bg-indigo-50' : 'border-slate-300 bg-slate-50'}`}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onClick={handleClick}
        >
            <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                className="hidden"
                onChange={handleFileChange}
            />
            <div className="space-y-4">
              <div className="mx-auto h-16 w-16 text-slate-400">
                <UploadIcon />
              </div>
              <p className="text-slate-600">
                <span className="font-semibold text-indigo-600">Click to upload</span> or drag and drop
              </p>
              <p className="text-xs text-slate-500">Facebook Ads Performance CSV File</p>
            </div>
        </div>
        <div className="mt-6 text-left">
            <h3 className="font-semibold text-slate-800">How to get your data:</h3>
            <ol className="list-decimal list-inside text-sm text-slate-600 mt-2 space-y-1">
                <li>Go to your <span className="font-semibold">Facebook Ads Manager</span>.</li>
                <li>Select the campaigns and date range you want to analyze.</li>
                <li>Click the <span className="font-semibold">'Reports'</span> dropdown and select <span className="font-semibold">'Export Table Data...'</span>.</li>
                <li>Choose <span className="font-semibold">'.csv'</span> as the format and export.</li>
            </ol>
        </div>
    </div>
  );
};

export default FileUpload;
