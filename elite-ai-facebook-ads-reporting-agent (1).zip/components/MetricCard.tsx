
import React from 'react';

interface MetricCardProps {
  title: string;
  value: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value }) => {
  return (
    <div className="bg-white p-4 rounded-xl shadow-lg border border-slate-200 transition-shadow hover:shadow-xl">
      <h4 className="text-sm font-medium text-slate-500 truncate">{title}</h4>
      <p className="text-2xl font-bold text-slate-800 mt-1">{value}</p>
    </div>
  );
};

export default MetricCard;
