
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { SendIcon, BotIcon } from './Icons';

interface ChatProps {
    history: ChatMessage[];
    isLoading: boolean;
    onSendMessage: (message: string) => Promise<void>;
}

const Chat: React.FC<ChatProps> = ({ history, isLoading, onSendMessage }) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [history]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSendMessage(input.trim());
      setInput('');
    }
  };

  return (
    <div className="flex flex-col h-[600px] bg-white rounded-xl shadow-lg border border-slate-200">
      <div className="p-4 border-b border-slate-200">
        <h3 className="flex items-center text-xl font-bold text-slate-800">
            <BotIcon className="h-6 w-6 mr-3 text-indigo-600" />
            Chat with Your Agent
        </h3>
        <p className="text-sm text-slate-500 mt-1">Ask follow-up questions about your report.</p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {history.map((msg, index) => (
          <div key={index} className={`flex items-end gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role === 'model' && <div className="flex-shrink-0 h-8 w-8 rounded-full bg-slate-200 flex items-center justify-center"><BotIcon className="h-5 w-5 text-slate-500" /></div>}
            <div className={`max-w-md lg:max-w-lg p-3 rounded-lg shadow-sm ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-slate-100 text-slate-800 rounded-bl-none'}`}>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">
                {msg.text}
                {isLoading && index === history.length - 1 && <span className="animate-pulse">▋</span>}
              </p>
            </div>
          </div>
        ))}
         <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-slate-200 bg-white/60 backdrop-blur-sm rounded-b-xl">
        <form onSubmit={handleSubmit} className="flex items-center space-x-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your campaigns..."
            className="flex-1 w-full px-4 py-2.5 text-sm bg-slate-100 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-shadow"
            disabled={isLoading}
            aria-label="Chat input"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="p-2.5 text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 disabled:cursor-not-allowed transition-all duration-200"
            aria-label="Send message"
          >
            <SendIcon className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default Chat;
